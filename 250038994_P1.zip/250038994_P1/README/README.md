# Enhanced ELIZA Chatbot

A modern, feature-rich implementation of the classic ELIZA chatbot with advanced capabilities including sentiment analysis, analytics dashboard, personality switching, and both CLI and web interfaces.

## Features

- **Multiple Personalities**: Choose from Psychotherapist, Eight-Year-Old Child, or Wise Mentor
- **Memory System**: Stores conversation context for later recall (keeps most recent 10 items)
- **Multi-sentence Processing**: Handles complex user inputs with multiple sentences
- **Sentiment-aware Responses**: Adapts responses based on user emotional state
- **GPT Fallback**: Intelligent responses for unmatched inputs using GPT or built-in alternatives
- **Analytics Dashboard**: Web-based dashboard with mood scores, sentiment tracking, and conversation history
- **Personality Switching**: Switch between personalities at runtime
- **Dual Interfaces**: Use via command-line or web browser

## Project Structure

```
.
├── eliza.py                  # Main Eliza conversation engine (CLI)
├── script.py                 # Script parser and data structures
├── app.py                    # Main Flask web application (chat + dashboard)
├── analytics_dashboard.py    # Standalone analytics dashboard
├── dashboard_charts.py      # Chart generation functions
├── requirements.txt          # Python dependencies
├── templates/
│   └── dashboard.html        # Dashboard template
├── static/                   # Generated charts (auto-created)
├── analytics/               # Session analytics (auto-created)
└── scripts/
    ├── therapist.txt         # Psychotherapist personality
    ├── child.txt             # Eight-year-old child
    └── mentor.txt            # Wise mentor
```

## Modules Overview

### eliza.py
The core conversation engine containing:
- `ElizaEngine`: Main chatbot that processes user input and generates responses
- `ConversationAnalytics`: Tracks session metrics (messages, sentiment, response times, memory recalls)
- `SentimentAnalyzer`: Analyzes user input sentiment using TextBlob
- `GPTFallback`: Handles unmatched inputs with intelligent responses
- `PersonalityManager`: Manages multiple personality switching

### script.py
Script parser and data structures:
- `Script`, `Keyword`, `DecompositionRule`, `ReassemblyRule`: Data classes for personality scripts
- `ScriptParser`: Parses personality script files
- `Sentiment`: Enum for sentiment types (POSITIVE, NEGATIVE, NEUTRAL, MIXED)

### app.py
Flask web application with:
- Chat interface at `/chat`
- Analytics dashboard at `/` (home route)
- Mood score calculation
- Real-time chart generation

### analytics_dashboard.py
Standalone analytics dashboard:
- Session overview with total messages, response times, duration
- Sentiment distribution pie chart
- Keyword usage bar chart
- Conversation history browser with modal details

### dashboard_charts.py
Chart generation functions:
- `generate_sentiment_timeline()`: Line chart showing sentiment over messages
- `generate_keyword_heatmap()`: Horizontal bar chart of top keywords
- `generate_sentiment_distribution()`: Pie chart of sentiment types

### scripts/
Personality script files:
- `therapist.txt`: Rogerian psychotherapist (default)
- `child.txt`: Eight-year-old child personality
- `mentor.txt`: Wise mentor personality

## Installation

```
bash
# Install dependencies
pip install -r requirements.txt
```

### Requirements
- Python 3.8+
- flask
- matplotlib
- pandas
- textblob

## Running the Program

### Option 1: Full Web Application (Recommended)

Start the complete web application with both chat and analytics dashboard:

```
bash
python app.py
```

Then open http://localhost:5000 in your browser.

The web app provides:
- **Chat Interface**: Interactive conversation with ELIZA
- **Analytics Dashboard**: Visual statistics including mood score, charts, and conversation history

### Option 2: Standalone Analytics Dashboard

Run just the analytics dashboard to view conversation statistics:

```
bash
python analytics_dashboard.py
```

This opens the dashboard at http://localhost:5000 showing:
- Total sessions and messages
- Average response time
- Memory recalls and GPT fallbacks
- Sentiment distribution pie chart
- Keyword usage bar chart
- List of all conversation sessions

### Option 3: Command-Line Interface (CLI)

Run ELIZA in the terminal:

```
bash
# Run with default personality (therapist)
python eliza.py

# Run with specific personality
python eliza.py --personality child
python eliza.py --personality mentor

# Disable analytics
python eliza.py --no-analytics

# Disable GPT fallback
python eliza.py --no-gpt

# List available personalities
python eliza.py --list-personalities

# Use custom personality script
python eliza.py --script path/to/your/script.txt
```

### Option 4: Generate Charts Only

Generate analytics charts from existing session data:

```
bash
python dashboard_charts.py
```

### Option 5: Test Script Parser

Test the personality script parser:

```
bash
python script.py
```

## Example Usage

```
PS C:\Users\donna\Desktop> cd C:/Users/donna/Desktop; python load_analytics.py
Loaded analytics from: session_20260226_140623
Total messages: 4
Sentiment distribution: {'positive': 3, 'negative': 1}
Keyword usage: {'i': 1, 'love': 3}

PS C:\Users\donna\Desktop> python app.py

==================================================
🧠 ELIZA Analytics Dashboard
==================================================
Starting dashboard at http://localhost:5000
Press Ctrl+C to stop

 * Serving Flask app 'app'
 * Debug mode: off
WARNING: This is a development server. Do not use it in a production deployment. Use a production WSGI server instead.
 * Running on all addresses (0.0.0.0)
 * Running on http://127.0.0.1:5000
 * Running on http://138.251.123.119:5000
Press CTRL+C to quit

PS C:\Users\donna\Desktop> python process_dialogues.py
Loading dialogues from: St Andrews\OOM,D,P\250038994_P1\sample_diaglogues\sample_dialogues.txt
Found 3 conversations

Processing therapist conversation 1...
  Processed 21 message pairs

Processing child conversation 2...
  Processed 22 message pairs

Processing mentor conversation 3...
  Processed 23 message pairs

==================================================
ANALYTICS SUMMARY
==================================================
Total messages: 62
Sentiment history: ['negative', 'negative', 'positive', 'negative', 'neutral', 'neutral', 'positive', 'negative', 'negative', 'negative', 'neutral', 'positive', 'neutral', 'neutral', 'positive', 'neutral', 'neutral', 'neutral', 'neutral', 'neutral', 'neutral', 'neutral', 'neutral', 'neutral', 'neutral', 'neutral', 'neutral', 'positive', 'neutral', 'positive', 'neutral', 'neutral', 'neutral', 'positive', 'neutral', 'positive', 'positive', 'positive', 'positive', 'positive', 'neutral', 'positive', 'negative', 'neutral', 'neutral', 'neutral', 'neutral', 'neutral', 'neutral', 'neutral', 'neutral', 'neutral', 'neutral', 'neutral', 'neutral', 'positive', 'positivtral', 'neutral']
Keyword usage: {'i': 45, 'feel': 2, 'always': 1, 'want': 2, 'you': 7, 'help': 2, 'me': 3}

Generating charts...

Saving analytics...
Analytics saved to: analytics/sample_dialogues.json

Charts generated successfully!
- static/sentiment_timeline.png
- static/keyword_heatmap.png
```

## Screenshots

![Dashboard Overview](./screenshots/dashboard.png) 

![Sentiment Timeline](./static/sentiment_timeline.png)

![Keyword Heatmap](./static/keyword_heatmap.png)

## Usage Examples

### CLI Conversation

```
$ python eliza.py --personality therapist
Hello. I am a psychotherapist. Please tell me what is on your mind today.

> I'm feeling really happy today!
Eliza: Thats wonderful to hear! What made you happy?

> It's because I got a promotion at work
Eliza: A promotion! Thats excellent news. How long have you been working towards this?

> About two years
Eliza: Two years of dedication. What do you think contributed most to your success?

> Goodbye
Eliza: It has been a pleasure talking with you. Remember, sometimes just talking about our problems can help us see them more clearly. Take care of yourself.
```

### Web Interface

The web application provides:
- **Chat Interface**: Interactive conversation with ELIZA in your browser
- **Analytics Dashboard**: Visual statistics including:
  - Mood score (percentage based on sentiment)
  - Sentiment timeline (line chart over messages)
  - Keyword heatmap (top 15 keywords used)
  - Conversation history (browse past conversations)
  - Memory recalls tracking

### Programmatic Usage

```
python
from eliza import ElizaEngine, PersonalityManager
from script import ScriptParser

# Create personality manager
pm = PersonalityManager()
pm.load_all_personalities()

# Switch between personalities
engine = pm.switch_personality('therapist', enable_analytics=True)
engine = pm.switch_personality('child', enable_analytics=True)
engine = pm.switch_personality('mentor', enable_analytics=True)

# Process input
response = engine.process_input("I'm feeling happy today!")
print(response)

# Access analytics
stats = engine.analytics.get_stats()
print(f"Total messages: {stats['total_messages']}")
print(f"Sentiment distribution: {stats['sentiment_distribution']}")
```

## Configuration

### Custom Scripts

Create custom personality scripts following the format in `scripts/`:

```
bash
# Run with custom script
python eliza.py --script path/to/your/script.txt
```

### Script File Format

```
NAME: Personality Name
DESCRIPTION: Description of the personality

WELCOME: Welcome message
FINAL: Goodbye message
QUIT: quit words list

DEFAULT: Default response 1
DEFAULT: Default response 2

PRE:
pattern -> replacement
...

KEYWORD: word priority
  DECOMP: decomposition pattern
    REASSEMBLY: response template
    REASSEMBLY: SENTIMENT:POSITIVE positive response

POST:
pattern -> replacement
...

SYNONYM: word synonym1 synonym2
```

## Analytics Data

Analytics are automatically saved to the `analytics/` directory as JSON files. Each session contains:
- Session ID and duration
- All messages with timestamps
- Sentiment history
- Keyword usage counts
- Response times
- Memory recall count
- GPT fallback count

View analytics via the web dashboard or standalone analytics dashboard.

## Credits

Based on the original ELIZA program by Joseph Weizenbaum (1966)

Enhanced for P1 CS5001 - Object-Oriented Modelling, Design and Programming

*Talk to ELIZA and explore the depths of conversation!*
