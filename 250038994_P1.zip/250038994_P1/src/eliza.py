"""
HI ! I'M DONNA, THIS IS MY FIRST PRACTICAL AND THRILLED TO CREATE IT WITH MODIFICATIONS(demonstrating modular design thinking) I HOPE YOU ENJOY INTERACTING WITH IT. CHEERS!
P1 CS5001 Eliza - Enhanced Eliza Engine

This module contains the main Eliza engine with advanced features:
- Memory system with context preservation
- Multi-sentence processing
- Sentiment-aware responses
- GPT fallback for unmatched inputs
- Analytics tracking
- Personality switching
"""

import re
import random
import sys
import json
import os
from datetime import datetime
from typing import List, Optional, Tuple, Dict, Any
from pathlib import Path
from collections import defaultdict

# line 20 is for implementing type hints (code documentation)
# Import sentiment analysis
try:
    from textblob import TextBlob
    TEXTBLOB_AVAILABLE = True
except ImportError:
    TEXTBLOB_AVAILABLE = False
    print("Warning: textblob not installed. Install with: pip install textblob")

# Ensure the script's directory is in sys.path for imports
# This allows running eliza.py from any directory
_script_dir = os.path.dirname(os.path.abspath(__file__))
if _script_dir not in sys.path:
    sys.path.insert(0, _script_dir)

try:
    from script import Script, ScriptParser, Keyword, DecompositionRule, ReassemblyRule, Sentiment # type: ignore
except ImportError as e:
    print(f"Error: Could not import script module. Make sure script.py exists in the same directory.")
    print(f"Details: {e}")
    print("To fix this:")
    print("1. Ensure script.py is in the same directory as this file")
    print("2. Or update the import path if script.py is in a subdirectory")
    sys.exit(1)


class ConversationAnalytics:
# ENHANCEMENT 5 tracks and stores conversation analytics
# This class collects runtime metrics, designed for behavioral tracking and future ML fine tuning
    
    def __init__(self, session_id: str):
        self.session_id = session_id
        self.start_time = datetime.now()
        self.messages: List[Dict] = []
        self.keyword_usage: Dict[str, int] = defaultdict(int)
        self.sentiment_history: List[str] = []
        self.response_times: List[float] = []
        self.memory_recalls: int = 0
        self.gpt_fallbacks: int = 0
        self.quit_count: int = 0
    
    def add_message(self, user_input: str, response: str, sentiment: str, 
                   keyword_used: Optional[str], response_time: float):
        # Add a message to the analytics,enables dataset generation for reinforcement learning experiments
        self.messages.append({
            'timestamp': datetime.now().isoformat(),
            'user_input': user_input,
            'response': response,
            'sentiment': sentiment,
            'keyword': keyword_used,
            'response_time': response_time
        })
        
        if keyword_used:
            self.keyword_usage[keyword_used] += 1
        
        self.sentiment_history.append(sentiment)
        self.response_times.append(response_time)
    
    def add_memory_recall(self):
        """Record a memory recall."""
        self.memory_recalls += 1
    
    def add_gpt_fallback(self):
        """Record a GPT fallback."""
        self.gpt_fallbacks += 1
    
    def add_quit(self):
        """Record conversation end."""
        self.quit_count += 1
    
    def get_stats(self) -> Dict[str, Any]:
        # Get conversation statistics, computes session level statistics for dashboard visualization
     
        duration = (datetime.now() - self.start_time).total_seconds()
        
        return {
            'session_id': self.session_id,
            'duration_seconds': duration,
            'total_messages': len(self.messages),
            'keyword_usage': dict(self.keyword_usage),
            'sentiment_distribution': self._get_sentiment_distribution(),
            'avg_response_time': sum(self.response_times) / len(self.response_times) if self.response_times else 0,
            'memory_recalls': self.memory_recalls,
            'gpt_fallbacks': self.gpt_fallbacks,
            'quit_count': self.quit_count
        }
    
    def _get_sentiment_distribution(self) -> Dict[str, int]:
        """enhancement3: Get distribution of sentiments."""
        dist = defaultdict(int)
        for s in self.sentiment_history:
            dist[s] += 1
        return dict(dist)
    
    def save_to_file(self, filepath: str):
        """Save analytics to JSON file."""
        data = self.get_stats()
        data['messages'] = self.messages
        data['start_time'] = self.start_time.isoformat()
        data['end_time'] = datetime.now().isoformat()
        
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)


class SentimentAnalyzer:
    """Analyzes sentiment of user input."""
    
    def __init__(self):
        self.threshold = 0.1
    
    def analyze(self, text: str) -> Tuple[Sentiment, float]:
        """
        Analyze sentiment of text.
        
        Returns:
            Tuple of (Sentiment, confidence_score)
        """
        if not TEXTBLOB_AVAILABLE:
            # Fallback to simple keyword-based analysis
            return self._simple_analysis(text)
        
        try:
            blob = TextBlob(text)
            polarity = blob.sentiment.polarity
            
            if polarity > self.threshold:
                return Sentiment.POSITIVE, abs(polarity)
            elif polarity < -self.threshold:
                return Sentiment.NEGATIVE, abs(polarity)
            else:
                return Sentiment.NEUTRAL, abs(polarity)
        except:
            return self._simple_analysis(text)
    
    def _simple_analysis(self, text: str) -> Tuple[Sentiment, float]:
        """Simple keyword-based sentiment analysis."""
        text_lower = text.lower()
        
        positive_words = {'happy', 'good', 'great', 'wonderful', 'love', 'joy', 
                        'excellent', 'amazing', 'fantastic', 'awesome', 'nice',
                        'pleased', 'delighted', 'glad', 'hope', 'better'}
        negative_words = {'sad', 'bad', 'terrible', 'hate', 'angry', 'awful',
                         'horrible', 'worst', 'depressed', 'anxious', 'worried',
                         'fear', 'afraid', 'scared', 'upset', 'frustrated', 'annoyed'}
        
        pos_count = sum(1 for w in positive_words if w in text_lower)
        neg_count = sum(1 for w in negative_words if w in text_lower)
        
        if pos_count > neg_count:
            confidence = min(pos_count / (pos_count + neg_count + 1), 1.0)
            return Sentiment.POSITIVE, confidence
        elif neg_count > pos_count:
            confidence = min(neg_count / (pos_count + neg_count + 1), 1.0)
            return Sentiment.NEGATIVE, confidence
        else:
            return Sentiment.NEUTRAL, 0.5


class GPTFallback:
    """enhancement 4:Handles GPT API fallback for unmatched inputs."""
    
    def __init__(self, api_key: Optional[str] = None, model: str = "gpt-3.5-turbo"):
        self.api_key = api_key or os.environ.get('OPENAI_API_KEY')
        self.model = model
        self.client = None
        self._setup_client()
    
    def _setup_client(self):
        """Setup OpenAI client."""
        # OpenAI is no longer available - always use mock responses
        pass
    
    def generate_response(self, user_input: str, context: Dict[str, Any]) -> Optional[str]:
        """
        Generate a response using GPT.
        
        Args:
            user_input: User's input text
            context: Context including personality, recent messages, etc.
            
        Returns:
            Generated response or None if unavailable
        """
        if not self.client:
            return self._mock_response(user_input, context)
        
        try:
            # Build context for GPT
            system_prompt = context.get('personality_description', 
                "You are ELIZA, a conversational AI chatbot.")
            
            recent_messages = context.get('recent_messages', [])
            
            messages = [
                {"role": "system", "content": system_prompt},
            ]
            
            # Add recent conversation history
            for msg in recent_messages[-5:]:  # Last 5 messages
                messages.append(msg)
            
            messages.append({"role": "user", "content": user_input})
            
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                max_tokens=150,
                temperature=0.7
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            print(f"GPT API error: {e}")
            return self._mock_response(user_input, context)
    
    def _mock_response(self, user_input: str, context: Dict) -> str:
        """Generate a mock response when GPT is unavailable."""
        personality = context.get('personality', 'therapist')
        
        # Simple keyword-based fallback responses
        responses = {
            'therapist': [
                "Tell me more about that.",
                "How does that make you feel?",
                "I see. What are your thoughts on that?",
                "That's interesting. Can you elaborate?",
                "What do you think that means?",
            ],
            'child': [
                "That's cool! Tell me more!",
                "Wow, really? What else?",
                "That's so neat! What happened next?",
                "I didn't know that! Tell me more!",
            ],
            'mentor': [
                "Interesting perspective. Elaborate on that.",
                "What wisdom do you draw from this?",
                "How does this relate to your journey?",
                "What does this teach you?",
            ]
        }
        
        return random.choice(responses.get(personality, responses['therapist']))


class ElizaEngine:
    """Main Eliza engine that handles conversations."""
    
    # Personality configurations
    PERSONALITIES = {
        'therapist': {
            'script_path': 'scripts/therapist.txt',
            'description': 'Rogerian psychotherapist'
        },
        'child': {
            'script_path': 'scripts/child_script.txt', 
            'description': 'Eight-year-old child'
        },
        'mentor': {
            'script_path': 'scripts/mentor.txt',
            'description': 'Wise mentor'
        }
    }
    
    def __init__(self, script: Script, personality: str = 'therapist',
                 enable_gpt_fallback: bool = True, enable_analytics: bool = True,
                 analytics_session_id: Optional[str] = None):
        self.script = script
        self.personality = personality
        self.memory_per_personality = defaultdict(list)
        self.memory = []  # Add memory list for the current personality
        self.last_keyword: Optional[str] = None
        self.last_sentiment: Sentiment = Sentiment.NEUTRAL
        self.conversation_context: List[Dict] = []
        
        # Additional features
        self.sentiment_analyzer = SentimentAnalyzer()
        self.gpt_fallback = GPTFallback() if enable_gpt_fallback else None
        self.analytics = ConversationAnalytics(analytics_session_id or 
                                                 f"session_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
        self.enable_analytics = enable_analytics
    
    def process_input(self, user_input: str) -> str:
        """Process user input and generate a response."""
        start_time = datetime.now()
        
        # Check for quit commands
        if self._is_quit(user_input):
            self.analytics.add_quit()
            return self.script.final_message
        
        # Analyze sentiment
        sentiment, confidence = self.sentiment_analyzer.analyze(user_input)
        self.last_sentiment = sentiment
        
        # Pre substitution
        processed = self._pre_substitute(user_input)
        
        # Handle multiple sentences
        sentences = self._split_sentences(processed)
        
        if len(sentences) > 1:
            response = self._process_multiple_sentences(sentences, sentiment)
        else:
            response = self._process_single_sentence(processed, sentiment)
        
        if not response:
            # Try GPT fallback
            if self.gpt_fallback:
                response = self._try_gpt_fallback(user_input)
                if response:
                    self.analytics.add_gpt_fallback()
            else:
                response = self._get_default_response(sentiment)
        
        # Track conversation context
        self.conversation_context.append({
            'user': user_input,
            'response': response
        })
        if len(self.conversation_context) > 10:
            self.conversation_context.pop(0)
        
        # Record analytics
        if self.enable_analytics:
            response_time = (datetime.now() - start_time).total_seconds()
            self.analytics.add_message(
                user_input, response, sentiment.value, 
                self.last_keyword, response_time
            )
        
        return response
    
    def _is_quit(self, text: str) -> bool:
        """Check if input contains a quit word."""
        text_lower = text.lower()
        for quit_word in self.script.quit_words:
            if quit_word.lower() in text_lower.split():
                return True
        return False
    
    def _pre_substitute(self, text: str) -> str:
        """Apply pre-substitution rules."""
        result = text
        for pattern, replacement in self.script.pre_substitutions.items():
            result = re.sub(r'\b' + re.escape(pattern) + r'\b', 
                          replacement, result, flags=re.IGNORECASE)
        return result
    
    def _post_substitute(self, text: str) -> str:
        """Apply post-substitution rules."""
        result = text
        for pattern, replacement in self.script.post_substitutions.items():
            result = re.sub(r'\b' + re.escape(pattern) + r'\b', 
                          replacement, result, flags=re.IGNORECASE)
        return result
    
    def _split_sentences(self, text: str) -> List[str]:
        """Split text into sentences."""
        sentences = re.split(r'(?<=[.!?]) +', text)
        return [s.strip() for s in sentences if s.strip()]
    
    def _find_keywords(self, text: str) -> List[Tuple[Keyword, int]]:
        """Find all keywords in text and return with their positions."""
        text_lower = text.lower()
        found = []
        
        for keyword in self.script.keywords:
            # Check main keyword
            if keyword.word.lower() in text_lower:
                pos = text_lower.find(keyword.word.lower())
                found.append((keyword, -keyword.priority, pos))
            
            # Check synonyms
            for syn in keyword.synonyms:
                if syn.lower() in text_lower:
                    pos = text_lower.find(syn.lower())
                    found.append((keyword, -(keyword.priority - 1), pos))  # Lower priority for synonyms
        
        # Also check script-level synonyms
        for main_word, synonyms in self.script.synonyms.items():
            for syn in synonyms:
                if syn.lower() in text_lower:
                    # Find the keyword this belongs to
                    for keyword in self.script.keywords:
                        if keyword.word.lower() == main_word.lower():
                            pos = text_lower.find(syn.lower())
                            found.append((keyword, -(keyword.priority - 1), pos))
        
        # Sort by priority (descending) then by position (ascending)
        found.sort(key=lambda x: (x[1], x[2]))
        
        return [(k, p) for k, p, pos in found]
    
    def _process_single_sentence(self, sentence: str, 
                                  sentiment: Sentiment) -> Optional[str]:
        """Process a single sentence and generate a response."""
        keywords = self._find_keywords(sentence)
        
        if not keywords:
            # Check memory if no keywords found
            if self.memory and random.random() < 0.3:
                response = self._recall_memory()
                if response:
                    self.analytics.add_memory_recall()
                    return response
            return None
        
        # Try each keyword in priority order
        for keyword, _ in keywords:
            response = self._try_keyword(keyword, sentence, sentiment)
            if response:
                self.last_keyword = keyword.word
                return response
        
        return None
    
    def _process_multiple_sentences(self, sentences: List[str], 
                                     sentiment: Sentiment) -> str:
        """Process multiple sentences."""
        responses = []
        
        for sentence in sentences:
            response = self._process_single_sentence(sentence, sentiment)
            if response:
                responses.append(response)
        
        if responses:
            return random.choice(responses)
        
        return self._get_default_response(sentiment)
    
    def _try_keyword(self, keyword: Keyword, sentence: str, 
                     sentiment: Sentiment) -> Optional[str]:
        """Try to generate a response using a specific keyword."""
        for decomp in keyword.decomposition_rules:
            captured = decomp.match(sentence)
            if captured is not None:
                # Try to find sentiment-matched reassembly first
                matching_reassemblies = [r for r in decomp.reassembly_rules 
                                       if r.sentiment == sentiment or r.sentiment == Sentiment.NEUTRAL]
                
                if matching_reassemblies:
                    reassembly = random.choice(matching_reassemblies)
                else:
                    reassembly = random.choice(decomp.reassembly_rules)
                
                response = reassembly.apply(captured, sentiment)
                response = self._post_substitute(response)
                
                # Handle memory trigger
                if reassembly.memory_trigger:
                    self._store_in_memory(sentence)
                
                return response
        
        return None
    
    def _store_in_memory(self, text: str):
        """Store text in memory with FIFO management (keeps most recent 10 items)."""
        if len(self.memory) >= 10:
            self.memory.pop(0)
        self.memory.append(text)
    
    def _recall_memory(self) -> str:
        """Recall something from memory."""
        if not self.memory:
            return None
        
        recalled = random.choice(self.memory)
        responses = [
            f"Earlier you mentioned {recalled}. Can you tell me more about that?",
            f"You said {recalled}. I'm curious about that.",
            f"Remember when you mentioned {recalled}? What did you mean by that?",
        ]
        return random.choice(responses)
    
    def _try_gpt_fallback(self, user_input: str) -> Optional[str]:
        """Try to generate a response using GPT."""
        if not self.gpt_fallback:
            return None
        
        context = {
            'personality': self.personality,
            'personality_description': self.script.description,
            'recent_messages': self.conversation_context[-5:] if self.conversation_context else []
        }
        
        return self.gpt_fallback.generate_response(user_input, context)
    
    def _get_default_response(self, sentiment: Sentiment = Sentiment.NEUTRAL) -> str:
        """Get a default response when no keyword matches."""
        # Try sentiment-specific defaults first
        if self.script.sentiment_responses:
            sentiment_key = sentiment.value
            if sentiment_key in self.script.sentiment_responses:
                responses = list(self.script.sentiment_responses[sentiment_key].values())
                if responses:
                    return random.choice(responses)
        
        # Use default responses
        defaults = self.script.default_responses if self.script.default_responses else [
            "I see. Tell me more about that.",
            "That's interesting. Please continue.",
            "I understand. What are your thoughts on that?",
            "Could you elaborate on that?",
            "Tell me more about yourself.",
            "How does that make you feel?",
            "What do you think about that?",
        ]
        
        # Try memory with lower probability
        if self.memory and random.random() < 0.3:
            response = self._recall_memory()
            if response:
                self.analytics.add_memory_recall()
                return response
        
        return random.choice(defaults)
    
    def run(self):
        """Run the Eliza conversation loop."""
        print(self.script.welcome_message)
        print()
        
        # Save analytics on exit
        if self.enable_analytics:
            analytics_dir = Path('analytics')
            analytics_dir.mkdir(exist_ok=True)
        
        while True:
            try:
                user_input = input("> ")
                
                if not user_input.strip():
                    print("Please say something...")
                    continue
                
                response = self.process_input(user_input)
                print(f"Eliza: {response}")
                print()
                
                if self._is_quit(user_input):
                    break
                    
            except KeyboardInterrupt:
                print("\nGoodbye!")
                break
        
        # Save analytics
        if self.enable_analytics:
            filepath = f"analytics/{self.analytics.session_id}.json"
            self.analytics.save_to_file(filepath)
            print(f"[Analytics saved to {filepath}]")


class PersonalityManager:
    """Manages multiple personalities and switching."""
    
    def __init__(self):
        self.personalities: Dict[str, Script] = {}
        self.current_personality: Optional[str] = None
        self.current_engine: Optional[ElizaEngine] = None
        self.parser = ScriptParser()
    
    def load_personality(self, name: str, script_path: str) -> bool:
        """Load a personality script."""
        try:
            script = self.parser.parse(script_path)
            script.name = name
            self.personalities[name] = script
            return True
        except Exception as e:
            print(f"Error loading personality '{name}': {e}")
            return False
    
    def load_all_personalities(self) -> int:
        """Load all built-in personalities."""
        loaded = 0
        
        for name, config in ElizaEngine.PERSONALITIES.items():
            if self.load_personality(name, config['script_path']):
                loaded += 1
        
        return loaded
    
    def switch_personality(self, name: str, **kwargs) -> Optional[ElizaEngine]:
        """Switch to a different personality."""
        if name not in self.personalities:
            print(f"Personality '{name}' not found. Available: {list(self.personalities.keys())}")
            return None
        
        self.current_personality = name
        self.current_engine = ElizaEngine(
            self.personalities[name],
            personality=name,
            **kwargs
        )
        return self.current_engine
    
    def get_available_personalities(self) -> List[str]:
        """Get list of available personalities."""
        return list(self.personalities.keys())


def main():
    """Main entry point for Eliza."""
    import argparse
    
    parser = argparse.ArgumentParser(description='Eliza - Enhanced Conversational Chatbot')
    parser.add_argument('--personality', '-p', 
                       choices=['therapist', 'child', 'mentor'],
                       default='therapist',
                       help='Choose personality (default: therapist)')
    parser.add_argument('--script', '-s', 
                       help='Custom script file path')
    parser.add_argument('--no-gpt', action='store_true',
                       help='Disable GPT fallback')
    parser.add_argument('--no-analytics', action='store_true',
                       help='Disable analytics tracking')
    parser.add_argument('--list-personalities', action='store_true',
                       help='List available personalities')
    
    args = parser.parse_args()
    
    # Create personality manager
    pm = PersonalityManager()
    loaded = pm.load_all_personalities()
    print(f"Loaded {loaded} personalities")
    
    if args.list_personalities:
        print("\nAvailable personalities:")
        for name in pm.get_available_personalities():
            script = pm.personalities[name]
            print(f"  - {name}: {script.description}")
        return
    
    # Determine script path
    if args.script:
        script_path = args.script
    else:
        script_path = ElizaEngine.PERSONALITIES[args.personality]['script_path']
    
    # Parse script
    script_parser = ScriptParser()
    try:
        script = script_parser.parse(script_path)
    except FileNotFoundError:
        print(f"Error: Script file '{script_path}' not found.")
        sys.exit(1)
    
    # Create and run Eliza
    eliza = ElizaEngine(
        script,
        personality=args.personality,
        enable_gpt_fallback=not args.no_gpt,
        enable_analytics=not args.no_analytics
    )
    
    eliza.run()


if __name__ == "__main__":
    main()
