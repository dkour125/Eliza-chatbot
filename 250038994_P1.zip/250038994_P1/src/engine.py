"""
ELIZA Engine Module
Core conversation engine for ELIZA chatbot

Enhancements:
1. Conversation analytics tracking (messages, sentiment, keywords, response times, etc.)
2. Sentiment analysis using TextBlob with keywords for better response matching
3. Memory system per personality for context aware responses
4. Multiple personality support with separate scripts (Q1 REQUIREMENT)
5. Quit detection and sentiment aware default responses (Q1 REQUIREMENT)
6. Analytics saving to JSON for dashboard integration
"""

import re
import random
from typing import List, Optional, Tuple, Dict, Any
from collections import defaultdict
from datetime import datetime
# special dictionary (defaultdict) that provides default values for missing keys and best for counting occurrences without checking if keys exist

# Enhancement 2: UsING TextBlob( a python lib) for processing text data,provides easy to use interface for NLP tasks ,better accuracy
try:
    from textblob import TextBlob
    TEXTBLOB_AVAILABLE = True
except ImportError:
    TEXTBLOB_AVAILABLE = False



class Sentiment:
    """Sentiment types."""
    POSITIVE = 'positive'
    NEGATIVE = 'negative'
    NEUTRAL = 'neutral'
    MIXED = 'mixed'


class ConversationAnalytics:
# enhancement 1:Tracks all sessions and stores conversation analytics.
    
    def __init__(self, session_id: str):
        self.session_id = session_id
        self.start_time = datetime.now()  # Record when the session starts
        self.messages: List[Dict] = []    # stores all conversation history
        self.keyword_usage: Dict[str, int] = defaultdict(int)   #tracks keyword usage counts
        self.sentiment_history: List[str] = []    # tracks sentiment of each user message
        self.response_times: List[float] = []     # tracks response times for performance analysis in seconds
        self.memory_recalls: int = 0              # counts how many times memory was recalled in responses
        self.gpt_fallbacks: int = 0               # counts when GPT had to step in (future enhancement)
        self.quit_count: int = 0                  # counts how many times user tried to quit
    
    def add_message(self, user_input: str, response: str, sentiment: str, 
                   keyword_used: Optional[str], response_time: float):
        """Add a message to the analytics."""
        self.messages.append({
            'timestamp': datetime.now().isoformat(),
            'user_input': user_input,
            'response': response,
            'sentiment': sentiment,
            'keyword': keyword_used,
            'response_time': response_time
        })
        
        if keyword_used:
            self.keyword_usage[keyword_used] += 1
        
        self.sentiment_history.append(sentiment)
        self.response_times.append(response_time)
    
    def add_memory_recall(self):   # Record a memory recall
        self.memory_recalls += 1
    
    def add_gpt_fallback(self):    # Record a GPT fallback
        self.gpt_fallbacks += 1
    
    def add_quit(self): # Record conversation end.
        self.quit_count += 1
    
    def get_stats(self) -> Dict[str, Any]:    # Get conversation statistics
        duration = (datetime.now() - self.start_time).total_seconds()
        
        return {
            'session_id': self.session_id,
            'duration_seconds': duration,
            'total_messages': len(self.messages),
            'keyword_usage': dict(self.keyword_usage),
            'sentiment_distribution': self._get_sentiment_distribution(),
            'avg_response_time': sum(self.response_times) / len(self.response_times) if self.response_times else 0,
            'memory_recalls': self.memory_recalls,
            'gpt_fallbacks': self.gpt_fallbacks,
            'quit_count': self.quit_count
        }
    
    def _get_sentiment_distribution(self) -> Dict[str, int]:
        # Get distribution of sentiments
        dist = defaultdict(int)
        for s in self.sentiment_history:
            dist[s] += 1
        return dict(dist)
    
    def save_to_file(self, filepath: str):
        # Save analytics to JSON file
        import json
        data = self.get_stats()
        data['messages'] = self.messages
        data['start_time'] = self.start_time.isoformat()
        data['end_time'] = datetime.now().isoformat()
        
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)


class SentimentAnalyzer:
    # enhancement 2 Analyzes sentiment of user input
    
    def __init__(self):
        self.threshold = 0.1
    
    def analyze(self, text: str) -> Tuple[Sentiment, float]:
        """Analyze sentiment of text.
        
        Returns:
            Tuple of (Sentiment, confidence_score).
        """
        
        if not TEXTBLOB_AVAILABLE:
            return self._simple_analysis(text)
        
        try:
            blob = TextBlob(text)
            polarity = blob.sentiment.polarity
            
            if polarity > self.threshold:
                return Sentiment.POSITIVE, abs(polarity)
            elif polarity < -self.threshold:
                return Sentiment.NEGATIVE, abs(polarity)
            else:
                return Sentiment.NEUTRAL, abs(polarity)
        except:
            return self._simple_analysis(text)
    
    def _simple_analysis(self, text: str) -> Tuple[Sentiment, float]:
        # Simple keyword-based sentiment analysis
        text_lower = text.lower()
        
        positive_words = {'happy', 'good', 'great', 'wonderful', 'love', 'joy', 
                        'excellent', 'amazing', 'fantastic', 'awesome', 'nice',
                        'pleased', 'delighted', 'glad', 'hope', 'better'}
        negative_words = {'sad', 'bad', 'terrible', 'hate', 'angry', 'awful',
                         'horrible', 'worst', 'depressed', 'anxious', 'worried',
                         'fear', 'afraid', 'scared', 'upset', 'frustrated', 'annoyed'}
        
        pos_count = sum(1 for w in positive_words if w in text_lower)
        neg_count = sum(1 for w in negative_words if w in text_lower)
        
        if pos_count > neg_count:
            confidence = min(pos_count / (pos_count + neg_count + 1), 1.0)
            return Sentiment.POSITIVE, confidence
        elif neg_count > pos_count:
            confidence = min(neg_count / (pos_count + neg_count + 1), 1.0)
            return Sentiment.NEGATIVE, confidence
        else:
            return Sentiment.NEUTRAL, 0.5


class ElizaEngine:
    # Main chatbot engine handling conversation, memory, and analytics
    # Enhancements:(3) Keyword detection and matching with decomposition/reassembly,
    # (4) Memory storage for context recall
    # (5) Personality support (therapist, child, mentor) 
    # (6) Quit and default response handling
    # (7) Analytics recording per message

    # Personality configurations
    PERSONALITIES = {
        'therapist': {
            'script_path': 'scripts/therapist.txt',
            'description': 'Rogerian psychotherapist'
        },
        'child': {
            'script_path': 'scripts/child.txt', 
            'description': 'Eight-year-old child'
        },
        'mentor': {
            'script_path': 'scripts/mentor.txt',
            'description': 'Wise mentor'
        }
    }
    
    def __init__(self, script, personality: str = 'therapist',
                 enable_gpt_fallback: bool = True, enable_analytics: bool = True,
                 analytics_session_id: Optional[str] = None):
        self.script = script
        self.personality = personality
        self.memory_per_personality = defaultdict(list)
        self.last_keyword: Optional[str] = None
        self.last_sentiment = Sentiment.NEUTRAL
        self.conversation_context: List[Dict] = []
        
        # Additional features
        self.sentiment_analyzer = SentimentAnalyzer()
        self.analytics = ConversationAnalytics(analytics_session_id or 
                                                 f"session_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
        self.enable_analytics = enable_analytics
    
    def process_input(self, user_input: str) -> str:
        """Process user input and generate a response."""
        start_time = datetime.now()
        
        # Check for quit commands
        if self._is_quit(user_input):
            self.analytics.add_quit()
            return self.script.final_message
        
        # Analyze sentiment
        sentiment, confidence = self.sentiment_analyzer.analyze(user_input)
        self.last_sentiment = sentiment
        
        # Pre substitution
        processed = self._pre_substitute(user_input)
        
        # Handle multiple sentences
        sentences = self._split_sentences(processed)
        
        if len(sentences) > 1:
            response = self._process_multiple_sentences(sentences, sentiment)
        else:
            response = self._process_single_sentence(processed, sentiment)
        
        if not response:
            response = self._get_default_response(sentiment)
        
        # Track conversation context
        self.conversation_context.append({
            'user': user_input,
            'response': response
        })
        if len(self.conversation_context) > 10:
            self.conversation_context.pop(0)
        
        # Record analytics
        if self.enable_analytics:
            response_time = (datetime.now() - start_time).total_seconds()
            self.analytics.add_message(
                user_input, response, sentiment.value if hasattr(sentiment, 'value') else str(sentiment), 
                self.last_keyword, response_time
            )
        
        return response
    
    def _is_quit(self, text: str) -> bool:
        # Check if input contains a quit word
        text_lower = text.lower()
        for quit_word in self.script.quit_words:
            if quit_word.lower() in text_lower.split():
                return True
        return False
    
    def _pre_substitute(self, text: str) -> str:
        # Apply pre substitution rules
        result = text
        for pattern, replacement in self.script.pre_substitutions.items():
            result = re.sub(r'\b' + re.escape(pattern) + r'\b', 
                          replacement, result, flags=re.IGNORECASE)
        return result
    
    def _post_substitute(self, text: str) -> str:
        # Apply post substitution rules
        result = text
        for pattern, replacement in self.script.post_substitutions.items():
            result = re.sub(r'\b' + re.escape(pattern) + r'\b', 
                          replacement, result, flags=re.IGNORECASE)
        return result
    
    def _split_sentences(self, text: str) -> List[str]:
        # Split text into sentences
        sentences = re.split(r'(?<=[.!?]) +', text)
        return [s.strip() for s in sentences if s.strip()]
    
    def _find_keywords(self, text: str) -> List[Tuple[Any, int]]:
        # Find all keywords in text and return with their positions
        text_lower = text.lower()
        found = []
        
        for keyword in self.script.keywords:
            if keyword.word.lower() in text_lower:
                pos = text_lower.find(keyword.word.lower())
                found.append((keyword, -keyword.priority, pos))
            
            # Check synonyms
            for syn in keyword.synonyms:
                if syn.lower() in text_lower:
                    pos = text_lower.find(syn.lower())
                    found.append((keyword, -(keyword.priority - 1), pos))
        
        # Sort by priority and position
        found.sort(key=lambda x: (x[1], x[2]))
        return [(k, p) for k, p, pos in found]

    def _process_single_sentence(self, sentence: str, 
                                  sentiment: Sentiment) -> Optional[str]:
        # Process a single sentence and generate a response
        keywords = self._find_keywords(sentence)
        
        if not keywords:
            # Check memory if no keywords found
            if self.memory and random.random() < 0.3:
                response = self._recall_memory()
                if response:
                    self.analytics.add_memory_recall()
                    return response
            return None
        
        # Try each keyword in priority order
        for keyword, _ in keywords:
            response = self._try_keyword(keyword, sentence, sentiment)
            if response:
                self.last_keyword = keyword.word
                return response
        
        return None

    def _process_multiple_sentences(self, sentences: List[str], 
                                     sentiment: Sentiment) -> str:
        # Process multiple sentences
        responses = []
        
        for sentence in sentences:
            response = self._process_single_sentence(sentence, sentiment)
            if response:
                responses.append(response)
        
        if responses:
            return random.choice(responses)
        
        return self._get_default_response(sentiment)

    def _try_keyword(self, keyword, sentence: str, 
                     sentiment: Sentiment) -> Optional[str]:
        # Try to generate a response using a specific keyword
        for decomp in keyword.decomposition_rules:
            captured = decomp.match(sentence)
            if captured is not None:
                # Try to find sentiment matched reassembly first
                matching_reassemblies = [r for r in decomp.reassembly_rules 
                                       if r.sentiment == sentiment or r.sentiment == Sentiment.NEUTRAL]
                
                if matching_reassemblies:
                    reassembly = random.choice(matching_reassemblies)
                else:
                    reassembly = random.choice(decomp.reassembly_rules)
                
                response = reassembly.apply(captured, sentiment)
                response = self._post_substitute(response)
                
                # Handle memory trigger
                if reassembly.memory_trigger:
                    self._store_in_memory(sentence)
                
                return response
        
        return None

    @property
    def memory(self):
        # Get memory for current personality
        return self.memory_per_personality[self.personality]

    def _store_in_memory(self, text: str):
        # Store text in memory with FIFO management (keeps most recent 10 items)
        # FIFO PREVENTS MEMORY FROM GROWING UNCONTROLLABLY
        if len(self.memory) >= 10:
            self.memory.pop(0)
        self.memory.append(text)

    def _recall_memory(self) -> str:
        # Recall something from memory"""
        if not self.memory:
            return None
        
        recalled = random.choice(self.memory)
        responses = [
            f"Earlier you mentioned {recalled}. Can you tell me more about that?",
            f"You said {recalled}. I'm curious about that.",
            f"Remember when you mentioned {recalled}? What did you mean by that?",
        ]
        return random.choice(responses)

    def _get_default_response(self, sentiment = Sentiment.NEUTRAL) -> str:
        """Get a default response when no keyword matches."""
        # Try sentiment specific defaults first
        if self.script.sentiment_responses:
            sentiment_key = sentiment.value if hasattr(sentiment, 'value') else str(sentiment)
            if sentiment_key in self.script.sentiment_responses:
                responses = list(self.script.sentiment_responses[sentiment_key].values())
                if responses:
                    return random.choice(responses)
        
        # Use default responses
        defaults = self.script.default_responses if self.script.default_responses else [
            "I see. Tell me more about that.",
            "That's interesting. Please continue.",
            "I understand. What are your thoughts on that?",
            "Could you elaborate on that?",
            "Tell me more about yourself.",
            "How does that make you feel?",
            "What do you think about that?",
        ]
        
        # Try memory with lower probability
        if self.memory and random.random() < 0.3:
            response = self._recall_memory()
            if response:
                self.analytics.add_memory_recall()
                return response
        
        return random.choice(defaults)

    def run(self):
        # Run the Eliza conversation loop
        print(self.script.welcome_message)
        print()
        
        # Save analytics on exit
        if self.enable_analytics:
            from pathlib import Path
            analytics_dir = Path('analytics')
            analytics_dir.mkdir(exist_ok=True)
        
        while True:
            try:
                user_input = input("> ")
                
                if not user_input.strip():
                    print("Please say something...")
                    continue
                
                response = self.process_input(user_input)
                print(f"Eliza: {response}")
                print()
                
                if self._is_quit(user_input):
                    break
                    
            except KeyboardInterrupt:
                print("\nGoodbye!")
                break
        
        # Save analytics
        if self.enable_analytics:
            filepath = f"analytics/{self.analytics.session_id}.json"
            self.analytics.save_to_file(filepath)
            print(f"[Analytics saved to {filepath}]")


if __name__ == "__main__":
    # Create a simple script object with required attributes for the engine
    class SimpleScript:
        def __init__(self):
            self.welcome_message = "Hello. I am ELIZA. How can I help you?"
            self.final_message = "Goodbye. It was nice talking to you."
            self.quit_words = ['quit', 'exit', 'bye', 'goodbye', 'done']
            self.pre_substitutions = {}
            self.post_substitutions = {}
            self.keywords = []
            self.default_responses = [
                "I see. Tell me more about that.",
                "That's interesting. Please continue.",
                "I understand. What are your thoughts on that?",
            ]
            self.sentiment_responses = {}
    
    script = SimpleScript()
    engine = ElizaEngine(script, personality='therapist')
    engine.run()
