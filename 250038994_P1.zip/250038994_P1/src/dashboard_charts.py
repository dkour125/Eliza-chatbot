"""
Dashboard Charts Module
Chart generation functions for ELIZA analytics

Enhancements:
1. Sentiment timeline chart for messages over time
2. Keyword heatmap showing top keywords used
3. Sentiment distribution pie chart
4. Hex color codes used for modern theme to make it look more visually appealing
5. Non interactive matplotlib backend for server-side chart generation
"""

import os
from pathlib import Path
from collections import defaultdict
# Enhancement 5: import of matplotlib, used non interactive Agg backend for server side rendering
try:
    import matplotlib
    matplotlib.use('Agg')    #no interactive backend for server side rendering
    import matplotlib.pyplot as plt
    HAVE_MATPLOTLIB = True
except ImportError:
    plt = None
    HAVE_MATPLOTLIB = False


def generate_sentiment_timeline(analytics, filename='static/sentiment_timeline.png'):
    """Generate sentiment timeline chart."""  
    #  enhancement1: generating sentiment timeline chart for showing user sentiment over messages
    if not HAVE_MATPLOTLIB:
        return
    
    # ensure static directory exists
    os.makedirs(os.path.dirname(filename) if os.path.dirname(filename) else 'static', exist_ok=True)
    
    if not hasattr(analytics, 'sentiment_history') or not analytics.sentiment_history:
        # creating empty chart
        plt.figure(figsize=(12, 6))
        plt.text(0.5, 0.5, 'No sentiment data yet', ha='center', va='center', fontsize=16)
        plt.savefig(filename, dpi=150, facecolor='#1a1a2e')
        plt.close()
        return
    
    sentiment_map = {'positive': 1, 'negative': -1, 'neutral': 0, 'mixed': 0.5}
    sentiment_values = [sentiment_map.get(s, 0) for s in analytics.sentiment_history]
    
    plt.figure(figsize=(12, 6))
    plt.plot(sentiment_values, marker='o', color='#00d9ff', linewidth=2, markersize=6)
    plt.axhline(y=0, color='gray', linestyle='--', alpha=0.5)
    plt.fill_between(range(len(sentiment_values)), sentiment_values, 0, alpha=0.3, color='#00d9ff')
    plt.xlabel('Message Number', color='white')
    plt.ylabel('Sentiment', color='white')
    plt.title('Sentiment Over Time', fontsize=14, color='white')
    plt.yticks([-1, 0, 1], ['Negative', 'Neutral', 'Positive'])
    plt.xticks(color='white')
    plt.yticks(color='white')
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(filename, dpi=150, facecolor='#1a1a2e', edgecolor='none')
    plt.close()


def generate_keyword_heatmap(analytics, filename='static/keyword_heatmap.png'):
    """Generate keyword heatmap chart."""
    if not HAVE_MATPLOTLIB:
        return
    
    # ensure static directory exists
    os.makedirs(os.path.dirname(filename) if os.path.dirname(filename) else 'static', exist_ok=True)
    
    if not hasattr(analytics, 'keyword_usage') or not analytics.keyword_usage:
        # Creating empty chart
        plt.figure(figsize=(12, 6))
        plt.text(0.5, 0.5, 'No keyword data yet', ha='center', va='center', fontsize=16)
        plt.savefig(filename, dpi=150, facecolor='#1a1a2e')
        plt.close()
        return
    
    keywords = dict(analytics.keyword_usage)
    if not keywords:
        plt.figure(figsize=(12, 6))
        plt.text(0.5, 0.5, 'No keyword data yet', ha='center', va='center', fontsize=16)
        plt.savefig(filename, dpi=150, facecolor='#1a1a2e')
        plt.close()
        return
    
    # Sort by count and take top 15
    sorted_keywords = sorted(keywords.items(), key=lambda x: x[1], reverse=True)[:15]
    labels = [k for k, v in sorted_keywords]
    counts = [v for k, v in sorted_keywords]
    
    plt.figure(figsize=(12, 6))
    bars = plt.barh(labels, counts, color='#00ff88', edgecolor='#00d9ff')
    plt.xlabel('Usage Count', color='white')
    plt.ylabel('Keywords', color='white')
    plt.title('Top Keyword Usage', fontsize=14, color='white')
    plt.xticks(color='white')
    plt.yticks(color='white')
    plt.gca().invert_yaxis()  # gca() = Get Current Axes
    plt.tight_layout()
    plt.savefig(filename, dpi=150, facecolor='#1a1a2e', edgecolor='none')
    plt.close()


def generate_sentiment_distribution(analytics, filename='static/sentiment_distribution.png'):
    """Generate sentiment distribution pie chart."""
    # Enhancement 3: Generating pie chart which shows sentiments distribution
    if not HAVE_MATPLOTLIB:
        return
    
    os.makedirs(os.path.dirname(filename) if os.path.dirname(filename) else 'static', exist_ok=True)
    
    if not hasattr(analytics, 'sentiment_history') or not analytics.sentiment_history:
        #Checks if the object analytics has an attribute named sentiment_history, returns true if the attribute exists and false if it does not.
        plt.figure(figsize=(8, 8))
        plt.text(0.5, 0.5, 'No sentiment data', ha='center', va='center', fontsize=16)
        plt.savefig(filename, dpi=150, facecolor='#1a1a2e')  # assume DPI as pixel density
        plt.close()
        return
    
    sentiment_counts = defaultdict(int)
    for s in analytics.sentiment_history:
        sentiment_counts[s] += 1
    
    colors = {'positive': '#00ff88', 'negative': '#ff6b6b', 'neutral': '#4ecdc4', 'mixed': '#ffe66d'}
    labels = list(sentiment_counts.keys())
    values = list(sentiment_counts.values())
    color_list = [colors.get(l, '#888') for l in labels]
    # hex code #00ff88(mint green color) for positive, #ff6b6b(light red) for negative, #4ecdc4(turquoise) for neutral, #ffe66d(light yellow) for mixed
    
    plt.figure(figsize=(8, 8))
    plt.pie(values, labels=labels, autopct='%1.1f%%', colors=color_list, startangle=90)    
    # autopct add percentages inside the pie slices,startangle=90 rotates the pie so the first slice starts at the top (North) rather than the right (East).

    plt.title('Sentiment Distribution', fontsize=14, color='white')
    plt.tight_layout()
    plt.savefig(filename, dpi=150, facecolor='#1a1a2e', edgecolor='none')
    plt.close()
