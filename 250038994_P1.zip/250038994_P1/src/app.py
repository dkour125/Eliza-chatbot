import matplotlib
matplotlib.use('Agg')

from flask import Flask, render_template, request, redirect, url_for
import os
import json
from pathlib import Path
from datetime import datetime

# Determine the correct base directory (where this script is located)
BASE_DIR = Path(__file__).parent.absolute()
os.chdir(BASE_DIR)  # Change working directory to script location

from eliza import ElizaEngine, ConversationAnalytics
from dashboard_charts import generate_sentiment_timeline, generate_keyword_heatmap # type: ignore

app = Flask(__name__)

# Global Eliza instance
eliza = None

def init_eliza():
    """Initialize Eliza with default settings."""
    global eliza
    from script import ScriptParser  # pyright: ignore[reportMissingImports]
    
    parser = ScriptParser()
    script = parser.parse('scripts/therapist.txt')
    eliza = ElizaEngine(script, personality='therapist', enable_analytics=True)
    return eliza

def load_saved_analytics():
    """Load analytics from saved JSON file if it exists."""
    analytics_dir = Path('analytics')
    
    if not analytics_dir.exists():
        return None
    
    # Find the latest analytics file
    json_files = list(analytics_dir.glob('*.json'))
    if not json_files:
        return None
    
    latest = max(json_files, key=os.path.getmtime)
    
    try:
        with open(latest, 'r') as f:
            data = json.load(f)
        
        # Create a new analytics object and populate it
        analytics = ConversationAnalytics(data.get('session_id', 'loaded'))
        analytics.start_time = datetime.fromisoformat(data['start_time']) if 'start_time' in data else datetime.now()
        analytics.messages = data.get('messages', [])
        analytics.sentiment_history = data.get('sentiment_history', [])
        analytics.response_times = data.get('response_times', [])
        analytics.memory_recalls = data.get('memory_recalls', 0)
        analytics.gpt_fallbacks = data.get('gpt_fallbacks', 0)
        analytics.quit_count = data.get('quit_count', 0)
        
        # Load keyword usage
        from collections import defaultdict
        keyword_data = data.get('keyword_usage', {})
        analytics.keyword_usage = defaultdict(int, keyword_data)
        
        return analytics
    except Exception as e:
        print(f"Error loading analytics: {e}")
        return None

# Initialize on startup
eliza = init_eliza()

@app.route('/')
# @: python decorator used to enhance functions without changing their code, other alternative is using inheritance
# using @ for more flexibility and less complexity, cheering me to code less and achieve more
def index():
    # Try to load saved analytics first
    analytics = load_saved_analytics()
    
    # If no saved analytics, use the current eliza instance
    if analytics is None:
        analytics = eliza.analytics

    # Generate charts - use relative paths for templates
    sentiment_chart = 'sentiment_timeline.png'
    keyword_chart = 'keyword_heatmap.png'

    # Ensure static folder exists
    os.makedirs('static', exist_ok=True)

    # Generate sentiment timeline chart
    if analytics.sentiment_history:
        try:
            generate_sentiment_timeline(analytics, filename='static/' + sentiment_chart)
            generate_keyword_heatmap(analytics, filename='static/' + keyword_chart)
        except Exception as e:
            print(f"Error generating charts: {e}")

    # Mood score calculation
    mood_score = 0
    if analytics.sentiment_history:
        sentiment_counts = {}
        for s in analytics.sentiment_history:
            sentiment_counts[s] = sentiment_counts.get(s, 0) + 1
        total = sum(sentiment_counts.values())
        if total > 0:
            positive = sentiment_counts.get('positive', 0)
            negative = sentiment_counts.get('negative', 0)
            mood_score = ((positive - negative) / total) * 100

    # Stats
    stats = analytics.get_stats()

    return render_template('dashboard.html',
                           mood_score=mood_score,
                           sentiment_chart=sentiment_chart,
                           keyword_chart=keyword_chart,
                           stats=stats)

@app.route('/chat', methods=['GET', 'POST'])
def chat():
    """Chat endpoint for interacting with Eliza."""
    response = None
    user_input = ""
    
    if request.method == 'POST':
        user_input = request.form.get('user_input', '')
        if user_input:
            response = eliza.process_input(user_input)
    
    # Get welcome message from the script
    welcome_message = eliza.script.welcome_message if eliza.script.welcome_message else "Hello! How are you feeling today?"
    
    return render_template('chat.html', response=response, user_input=user_input, welcome_message=welcome_message)

@app.route('/run-eliza')
def run_eliza_route():
    import subprocess
    subprocess.Popen(["python", "eliza.py"])
    return redirect(url_for('index'))

def run_dashboard(host='0.0.0.0', port=5000):
    """Run the analytics dashboard."""
    Path("analytics").mkdir(parents=True, exist_ok=True)
    Path("static").mkdir(parents=True, exist_ok=True)

    print(f"\n{'='*50}")
    print("🧠 ELIZA Analytics Dashboard")
    print(f"{'='*50}")
    print(f"Starting dashboard at http://localhost:{port}")
    print("Press Ctrl+C to stop\n")

    # Important: disable reloader to avoid Windows socket errors
    # windows handles socket binding differentlt than linux/mac
    # When Flask runs with reloader enabled i.e. (use_reloader=True), it creates two processes
    # the parent process which monitors for code changes, the child processwhich actually runs your app
    # and that address is already in use
    app.run(host=host, port=port, debug=False, use_reloader=False)


if __name__ == "__main__":
    run_dashboard()
