"""
Load saved analytics for the dashboard.
"""
# STANDARD LIBRARY IMPORTS
# These imports are from Python's standard library and require no additional installation as they provide file handling and JSON parsing functionality.
import json
import os
from pathlib import Path

def get_latest_analytics():
    """Get the most recent analytics data."""
    analytics_dir = Path('analytics')
     # Using Path() ensures cross-platform compatibility (Windows/Mac/Linux)
    if not analytics_dir.exists():
        return None
    
    # Find the latest analytics file
    # glob('*.json') returns an iterator of all files ending with .json 
    json_files = list(analytics_dir.glob('*.json'))
    if not json_files:
        return None
    
    latest = max(json_files, key=os.path.getmtime)
    
    with open(latest, 'r') as f:
        return json.load(f)

if __name__ == "__main__":
    data = get_latest_analytics()
    if data:
        print(f"Loaded analytics from: {data.get('session_id')}")
        print(f"Total messages: {data.get('total_messages')}")
        print(f"Sentiment distribution: {data.get('sentiment_distribution')}")
        print(f"Keyword usage: {data.get('keyword_usage')}")
    else:
        print("No analytics found")
