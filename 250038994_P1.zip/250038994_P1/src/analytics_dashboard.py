"""
ELIZA Analytics Dashboard
Web-based dashboard for viewing conversation analytics
"""

import os
import json
import glob
from datetime import datetime
from pathlib import Path
from collections import defaultdict

from flask import Flask, render_template_string, jsonify, request, redirect, url_for
try:
    import matplotlib
    matplotlib.use('Agg')  # Use non-interactive backend
    import matplotlib.pyplot as plt
    HAVE_MATPLOTLIB = True
except ImportError:
    matplotlib = None
    plt = None
    HAVE_MATPLOTLIB = False

app = Flask(__name__)
app.secret_key = 'eliza_analytics_secret_key'

# Template for the dashboard
DASHBOARD_TEMPLATE = '''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ELIZA Analytics Dashboard</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: #fff;
            min-height: 100vh;
        }
        .header {
            background: linear-gradient(90deg, #0f3460 0%, #16213e 100%);
            padding: 20px 40px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.3);
        }
        .header h1 {
            font-size: 2rem;
            background: linear-gradient(90deg, #00d9ff, #00ff88);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .container { max-width: 1400px; margin: 0 auto; padding: 30px 20px; }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: rgba(255,255,255,0.1);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 25px;
            text-align: center;
            border: 1px solid rgba(255,255,255,0.1);
            transition: transform 0.3s, box-shadow 0.3s;
        }
        .stat-card:hover { transform: translateY(-5px); box-shadow: 0 10px 30px rgba(0,0,0,0.3); }
        .stat-value { font-size: 2.5rem; font-weight: bold; color: #00d9ff; }
        .stat-label { color: #aaa; margin-top: 5px; font-size: 0.9rem; }
        .chart-container {
            background: rgba(255,255,255,0.1);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 30px;
            border: 1px solid rgba(255,255,255,0.1);
        }
        .chart-container h2 { margin-bottom: 20px; color: #00ff88; }
        .charts-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 20px; }
        .chart { background: rgba(0,0,0,0.2); border-radius: 10px; padding: 15px; }
        .chart img { max-width: 100%; border-radius: 8px; }
        .session-list {
            background: rgba(255,255,255,0.1);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 25px;
            border: 1px solid rgba(255,255,255,0.1);
        }
        .session-list h2 { margin-bottom: 20px; color: #00ff88; }
        .session-item {
            background: rgba(0,0,0,0.2);
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            cursor: pointer;
            transition: background 0.3s;
        }
        .session-item:hover { background: rgba(0,0,0,0.4); }
        .session-info { flex: 1; }
        .session-id { font-weight: bold; color: #00d9ff; }
        .session-stats { color: #aaa; font-size: 0.85rem; }
        .btn {
            background: linear-gradient(90deg, #00d9ff, #00ff88);
            color: #1a1a2e;
            border: none;
            padding: 10px 20px;
            border-radius: 25px;
            cursor: pointer;
            font-weight: bold;
            text-decoration: none;
            transition: transform 0.3s, box-shadow 0.3s;
        }
        .btn:hover { transform: translateY(-2px); box-shadow: 0 5px 20px rgba(0,217,255,0.4); }
        .modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.8); z-index: 1000; overflow-y: auto; }
        .modal-content {
            background: #1a1a2e;
            margin: 5% auto;
            padding: 30px;
            border-radius: 15px;
            max-width: 800px;
            width: 90%;
            border: 1px solid rgba(255,255,255,0.1);
        }
        .close { float: right; font-size: 28px; font-weight: bold; color: #aaa; cursor: pointer; }
        .close:hover { color: #fff; }
        .message-list { max-height: 400px; overflow-y: auto; }
        .message { padding: 10px 15px; margin-bottom: 10px; border-radius: 10px; }
        .message-user { background: rgba(0,217,255,0.2); margin-left: 20%; }
        .message-eliza { background: rgba(0,255,136,0.2); margin-right: 20%; }
        .empty-state { text-align: center; padding: 60px 20px; color: #aaa; }
        .empty-state h2 { margin-bottom: 15px; color: #00d9ff; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
        .animate-in { animation: fadeIn 0.5s ease-out; }
    </style>
</head>
<body>
    <div class="header"><h1> ELIZA Analytics Dashboard</h1></div>
    <div class="container">
        {% if sessions %}
        <div class="stats-grid animate-in">
            <div class="stat-card"><div class="stat-value">{{ total_sessions }}</div><div class="stat-label">Total Sessions</div></div>
            <div class="stat-card"><div class="stat-value">{{ total_messages }}</div><div class="stat-label">Total Messages</div></div>
            <div class="stat-card"><div class="stat-value">{{ avg_response_time }}s</div><div class="stat-label">Avg Response Time</div></div>
            <div class="stat-card"><div class="stat-value">{{ total_memory_recalls }}</div><div class="stat-label">Memory Recalls</div></div>
            <div class="stat-card"><div class="stat-value">{{ total_gpt_fallbacks }}</div><div class="stat-label">GPT Fallbacks</div></div>
        </div>
        <div class="charts-grid animate-in" style="animation-delay: 0.1s">
            <div class="chart-container"><h2> Sentiment Distribution</h2><div class="chart"><img src="{{ url_for('static', filename='sentiment_chart.png') }}" alt="Sentiment Chart"></div></div>
            <div class="chart-container"><h2> Keyword Usage</h2><div class="chart"><img src="{{ url_for('static', filename='keyword_chart.png') }}" alt="Keyword Chart"></div></div>
        </div>
        <div class="session-list animate-in" style="animation-delay: 0.2s">
            <h2> Conversation Sessions</h2>
            {% for session in sessions %}
            <div class="session-item" onclick="showSession('{{ session.session_id }}')">
                <div class="session-info">
                    <div class="session-id">{{ session.session_id }}</div>
                    <div class="session-stats">{{ session.total_messages }} messages | {{ "%.1f"|format(session.duration_seconds / 60) }} min | {{ session.start_time[:19] }}</div>
                </div>
                <span class="btn">View</span>
            </div>
            {% endfor %}
        </div>
        <div id="sessionModal" class="modal">
            <div class="modal-content">
                <span class="close" onclick="closeModal()">&times;</span>
                <h2 id="modalTitle">Session Details</h2>
                <div id="modalBody"></div>
            </div>
        </div>
        {% else %}
        <div class="empty-state animate-in">
            <h2>No Analytics Data Yet</h2>
            <p>Start a conversation with ELIZA to see analytics here!</p>
            <br>
            <a href="#" class="btn">Run ELIZA</a>
        </div>
        {% endif %}
    </div>
    <script>
        function showSession(sessionId) {
            fetch('/api/session/' + sessionId).then(response => response.json()).then(data => {
                document.getElementById('modalTitle').textContent = 'Session: ' + sessionId;
                let html = '<div class="stats-grid" style="margin-bottom: 20px;">';
                html += '<div class="stat-card"><div class="stat-value">' + data.total_messages + '</div><div class="stat-label">Messages</div></div>';
                html += '<div class="stat-card"><div class="stat-value">' + data.duration_seconds.toFixed(1) + 's</div><div class="stat-label">Duration</div></div>';
                html += '<div class="stat-card"><div class="stat-value">' + data.avg_response_time.toFixed(2) + 's</div><div class="stat-label">Avg Response</div></div>';
                html += '</div><h3>Conversation</h3><div class="message-list">';
                for (let msg of data.messages) {
                    html += '<div class="message message-user"><strong>You:</strong> ' + msg.user_input + '</div>';
                    html += '<div class="message message-eliza"><strong>ELIZA:</strong> ' + msg.response + '</div>';
                }
                html += '</div>';
                document.getElementById('modalBody').innerHTML = html;
                document.getElementById('sessionModal').style.display = 'block';
            });
        }
        function closeModal() { document.getElementById('sessionModal').style.display = 'none'; }
        window.onclick = function(event) { if (event.target == document.getElementById('sessionModal')) { closeModal(); } }
    </script>
</body>
</html>
'''


def load_all_sessions():
    # Load all session analytics from files
    # except exception as e is used when code in the try block fails, the except block catches the error and lets you decide what to do next
    analytics_dir = Path('analytics')
    sessions = []
    if not analytics_dir.exists():
        return sessions
    for filepath in sorted(analytics_dir.glob('*.json'), reverse=True):
        try:
            with open(filepath, 'r') as f:
                data = json.load(f)
                sessions.append(data)
        except Exception as e:
            print(f"Error loading {filepath}: {e}")
    return sessions 


def generate_charts(sessions):
    """Generate analytics charts."""
    static_dir = Path("static")   
    static_dir.mkdir(parents=True, exist_ok=True)   # safe directory
    
    if not HAVE_MATPLOTLIB:
        print("matplotlib not available, skipping chart generation")
        return
    
    all_sentiments = defaultdict(int)
    all_keywords = defaultdict(int)
    
    for session in sessions:
        for sentiment, count in session.get('sentiment_distribution', {}).items():
            all_sentiments[sentiment] += count
        for keyword, count in session.get('keyword_usage', {}).items():
            all_keywords[keyword] += count
    
    if all_sentiments and sum(all_sentiments.values()) > 0:
        plt.figure(figsize=(10, 6))
        colors = {'positive': '#00ff88', 'negative': '#ff6b6b', 'neutral': '#4ecdc4', 'mixed': '#ffe66d'}
        labels = list(all_sentiments.keys())
        values = list(all_sentiments.values())
        color_list = [colors.get(l, '#888') for l in labels]
        plt.pie(values, labels=labels, autopct='%1.1f%%', colors=color_list, startangle=90)
        plt.title('Sentiment Distribution', fontsize=14, color='white')
        plt.tight_layout()
        plt.savefig('static/sentiment_chart.png', dpi=150, facecolor='#1a1a2e', edgecolor='none')
        plt.close()
    
    if all_keywords and sum(all_keywords.values()) > 0:
        plt.figure(figsize=(12, 6))
        sorted_keywords = sorted(all_keywords.items(), key=lambda x: x[1], reverse=True)[:15]
        keywords = [k for k, v in sorted_keywords]
        counts = [v for k, v in sorted_keywords]
        bars = plt.bar(keywords, counts, color='#00d9ff', edgecolor='#00ff88')
        plt.xlabel('Keywords', color='white')
        plt.ylabel('Usage Count', color='white')
        plt.title('Top 15 Keyword Usage', fontsize=14, color='white')
        plt.xticks(rotation=45, ha='right', color='white')
        plt.yticks(color='white')
        plt.tight_layout()
        plt.savefig('static/keyword_chart.png', dpi=150, facecolor='#1a1a2e', edgecolor='none')
        plt.close()


@app.route('/')
def index():
    """Main dashboard page."""
    sessions = load_all_sessions()
    if sessions:
        total_sessions = len(sessions)
        total_messages = sum(s.get('total_messages', 0) for s in sessions)
        all_response_times = []
        for s in sessions:
            all_response_times.extend(s.get('response_times', []))
        avg_response_time = sum(all_response_times) / len(all_response_times) if all_response_times else 0
        total_memory_recalls = sum(s.get('memory_recalls', 0) for s in sessions)
        total_gpt_fallbacks = sum(s.get('gpt_fallbacks', 0) for s in sessions)
        generate_charts(sessions)
        return render_template_string(DASHBOARD_TEMPLATE,
            sessions=sessions, total_sessions=total_sessions, total_messages=total_messages,
            avg_response_time=avg_response_time, total_memory_recalls=total_memory_recalls,
            total_gpt_fallbacks=total_gpt_fallbacks)
    else:
        return render_template_string(DASHBOARD_TEMPLATE, sessions=[])


@app.route('/api/session/<session_id>')
def get_session(session_id):
    """Get details for a specific session."""
    filepath = Path(f'analytics/{session_id}.json')
    if filepath.exists():
        with open(filepath, 'r') as f:
            return jsonify(json.load(f))
    return jsonify({'error': 'Session not found'}), 404


@app.route('/api/sessions')
def get_all_sessions():
    """Get list of all sessions."""
    sessions = load_all_sessions()
    return jsonify([{
        'session_id': s.get('session_id'),
        'total_messages': s.get('total_messages'),
        'duration_seconds': s.get('duration_seconds'),
        'start_time': s.get('start_time')
    } for s in sessions])


def run_dashboard(host='0.0.0.0', port=5000):
    """Run the analytics dashboard."""
    Path("analytics").mkdir(parents=True, exist_ok=True)
    Path("static").mkdir(parents=True, exist_ok=True)
    print(f"\n{'='*50}")
    print("ELIZA Analytics Dashboard")
    print(f"{'='*50}")
    print(f"Starting dashboard at http://localhost:{port}")
    print(f"Press Ctrl+C to stop\n")
    app.run(host=host, port=port, debug=False)


if __name__ == '__main__':
    run_dashboard()
