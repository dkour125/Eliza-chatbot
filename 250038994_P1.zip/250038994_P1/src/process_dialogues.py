"""
Process sample dialogues through Eliza to generate real analytics and charts.
"""
# batch processing script for my bot
import os
import json
from pathlib import Path
from eliza import ElizaEngine
from script import ScriptParser # type: ignore
from dashboard_charts import generate_sentiment_timeline, generate_keyword_heatmap # type: ignore


def load_config():
    """Load configuration from config.json file."""
    config_path = Path(__file__).parent / 'config.json'
    if config_path.exists():
        with open(config_path, 'r') as f:
            return json.load(f)
    return {}


def parse_dialogue_file(filepath):
    """Parse the sample dialogues file and extract conversations."""
    with open(filepath, 'r') as f:
        content = f.read()
    
    conversations = []
    current_conversation = None
    current_lines = []
    
    lines = content.split('\n')
    for line in lines:
        if 'PSYCHOTHERAPIST SESSION' in line:
            if current_conversation:
                conversations.append(current_conversation)
            current_conversation = {'personality': 'therapist', 'lines': []}
        elif 'EIGHT YEAR OLD CHILD SESSION' in line:
            if current_conversation:
                conversations.append(current_conversation)
            current_conversation = {'personality': 'child', 'lines': []}
        elif 'WISE MENTOR SESSION' in line:
            if current_conversation:
                conversations.append(current_conversation)
            current_conversation = {'personality': 'mentor', 'lines': []}
        elif current_conversation is not None:
            # Skip empty lines and section headers
            if line.strip() and not line.startswith('===') and not line.startswith('#'):
                current_conversation['lines'].append(line.strip())
    
    if current_conversation:
        conversations.append(current_conversation)
    
    return conversations

def process_conversation(eliza, lines):
    """Process a conversation through Eliza and collect responses."""
    responses = []
    
    for line in lines:
        # Skip Eliza's initial greeting
        if line.startswith('Eliza:'):
            continue
        
        # This is user input (starts with >)
        if line.startswith('> '):
            user_input = line[2:]  # Remove '> '
            response = eliza.process_input(user_input)
            responses.append((user_input, response))
        elif line.startswith('ELIZA:'):
            # Handle uppercase ELIZA responses
            continue
            
    return responses

def main():
    # Ensure static folder exists
    os.makedirs('static', exist_ok=True)
    
    # Load configuration
    config = load_config()
    
    # Initialize Eliza with therapist personality
    parser = ScriptParser()
    script = parser.parse('scripts/therapist.txt')
    eliza = ElizaEngine(script, personality='therapist', enable_analytics=True)
    
    # Get dialogue path from config, fallback to default
    config_dialogue_path = config.get('sample_dialogues_path')
    if config_dialogue_path:
        dialogue_path = Path(config_dialogue_path)
    else:
        dialogue_path = Path(__file__).parent / 'sample_dialogues.txt'
    print(f"Loading dialogues from: {dialogue_path}")
    
    try:
        conversations = parse_dialogue_file(dialogue_path)
        print(f"Found {len(conversations)} conversations")
        
        # Process each conversation
        for i, conv in enumerate(conversations):
            print(f"\nProcessing {conv['personality']} conversation {i+1}...")
            responses = process_conversation(eliza, conv['lines'])
            print(f"  Processed {len(responses)} message pairs")
        
        # Print analytics
        analytics = eliza.analytics
        print("\n" + "="*50)
        print("ANALYTICS SUMMARY")
        print("="*50)
        print(f"Total messages: {len(analytics.messages)}")
        print(f"Sentiment history: {analytics.sentiment_history}")
        print(f"Keyword usage: {dict(analytics.keyword_usage)}")
        
        # Generate charts
        print("\nGenerating charts...")
        generate_sentiment_timeline(analytics, filename='static/sentiment_timeline.png')
        generate_keyword_heatmap(analytics, filename='static/keyword_heatmap.png')
        
        # Save analytics to file
        print("\nSaving analytics...")
        Path("analytics").mkdir(exist_ok=True)
        analytics_file = f"analytics/sample_dialogues.json"
        analytics.save_to_file(analytics_file)
        print(f"Analytics saved to: {analytics_file}")
        
        print("\nCharts generated successfully!")
        print("- static/sentiment_timeline.png")
        print("- static/keyword_heatmap.png")
        
    except FileNotFoundError:
        print(f"Error: Could not find {dialogue_path}")
        print("Please make sure the path is correct.")
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
