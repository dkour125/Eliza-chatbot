"""Quick test to generate new analytics"""
import sys
sys.path.insert(0, '.')

from eliza import ElizaEngine
from script_parser import ScriptParser

# Load script
parser = ScriptParser()
script = parser.parse('scripts/therapist.txt')

# Create Eliza
eliza = ElizaEngine(script, personality='therapist', enable_analytics=True)

# Simulate a conversation
messages = [
    "Hello, I am feeling happy today",
    "I love programming",
    "My day was wonderful",
    "I am a bit tired though",
    "quit"
]

print("Starting conversation...\n")
for msg in messages:
    print(f"You: {msg}")
    response = eliza.process_input(msg)
    print(f"Eliza: {response}\n")
    if eliza._is_quit(msg):
        break

# Save analytics
eliza.analytics.save_to_file(f"analytics/{eliza.analytics.session_id}.json")
print(f"\nAnalytics saved to analytics/{eliza.analytics.session_id}.json")
print(f"Total messages: {len(eliza.analytics.messages)}")
print(f"Sentiment history: {eliza.analytics.sentiment_history}")
print(f"Keyword usage: {dict(eliza.analytics.keyword_usage)}")
