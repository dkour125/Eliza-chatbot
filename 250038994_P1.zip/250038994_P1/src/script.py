"""
P1 CS5001 Eliza - Enhanced Script Parser and Data Structures

This module contains the data structures and parser for Eliza script files.
Includes support for:
- Advanced decomposition patterns
- Context preservation
- Sentiment-aware responses
- Memory triggers
"""

import re
from typing import List, Dict, Optional, Tuple, Any
from dataclasses import dataclass, field
from enum import Enum


class Sentiment(Enum):
    """Sentiment types for response generation."""
    POSITIVE = "positive"
    NEGATIVE = "negative"
    NEUTRAL = "neutral"
    MIXED = "mixed"


@dataclass
class ReassemblyRule:
    """Represents a reassembly rule with a template string."""
    
    template: str
    sentiment: Sentiment = Sentiment.NEUTRAL
    memory_trigger: bool = False
    
    def apply(self, captured: List[str], sentiment: Sentiment = Sentiment.NEUTRAL) -> str:
        """
        Apply the reassembly rule using captured groups.
        
        Args:
            captured: List of captured strings from decomposition
            sentiment: Current sentiment of user input
            
        Returns:
            The reassembled string
        """
        result = self.template
        for i, cap in enumerate(captured):
            result = result.replace(f'({i+1})', cap)
        
        # Handle memory trigger
        if '(MEMORY)' in result:
            result = result.replace('(MEMORY)', '')
        
        return result
    
    def __repr__(self):
        return f"ReassemblyRule('{self.template}')"


@dataclass
class DecompositionRule:
    """Represents a decomposition rule with a pattern and reassembly rules."""
    
    pattern: str
    reassembly_rules: List[ReassemblyRule] = field(default_factory=list)
    context_required: bool = False
    priority_boost: int = 0
    
    _regex: re.Pattern = field(init=False, repr=False)
    
    def __post_init__(self):
        self._regex = self._compile_pattern(self.pattern)
    
    def _compile_pattern(self, pattern: str) -> re.Pattern:
        """Convert decomposition pattern to regex."""
        regex_pattern = pattern
        # Handle special patterns
        regex_pattern = regex_pattern.replace('*', '.*?')  # Wildcard
        regex_pattern = re.sub(r'\(([A-Z])\)', r'(.*?)', regex_pattern)  # (X) patterns
        return re.compile('^' + regex_pattern + '$', re.IGNORECASE)
    
    def match(self, text: str) -> Optional[List[str]]:
        """
        Try to match and decompose the input text.
        
        Args:
            text: Input string to decompose
            
        Returns:
            List of captured groups if matched, None otherwise
        """
        match = self._regex.match(text.strip())
        if match:
            return list(match.groups())
        return None
    
    def __repr__(self):
        return f"DecompositionRule('{self.pattern}')"


@dataclass
class Keyword:
    """Represents a keyword with priority and decomposition rules."""
    
    word: str
    priority: int
    decomposition_rules: List[DecompositionRule] = field(default_factory=list)
    synonyms: List[str] = field(default_factory=list)
    context_dependent: bool = False
    sentiment_boost: Dict[str, int] = field(default_factory=dict)
    
    def __repr__(self):
        return f"Keyword('{self.word}', priority={self.priority})"


@dataclass
class Script:
    """
    Represents a complete Eliza script with all its components.
    """
    
    name: str = ""
    description: str = ""
    welcome_message: str = ""
    final_message: str = ""
    quit_words: List[str] = field(default_factory=list)
    pre_substitutions: Dict[str, str] = field(default_factory=dict)
    keywords: List[Keyword] = field(default_factory=list)
    post_substitutions: Dict[str, str] = field(default_factory=dict)
    synonyms: Dict[str, List[str]] = field(default_factory=dict)
    default_responses: List[str] = field(default_factory=list)
    sentiment_responses: Dict[str, Dict[str, str]] = field(default_factory=dict)


class ScriptParser:
    """Parser for Eliza script files with advanced features."""
    
    def __init__(self):
        self.current_section = None
        self.current_keyword = None
        self.current_decomp = None
        self.script = Script()
    
    def parse(self, filepath: str) -> Script:
        """Parse an Eliza script file."""
        with open(filepath, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        
        i = 0
        while i < len(lines):
            line = lines[i].strip()
            
            # Skip empty lines and comments
            if not line or line.startswith('#'):
                i += 1
                continue
            
            # Parse sections
            if line.startswith('NAME:'):
                self.script.name = line[len('NAME:'):].strip()
            
            elif line.startswith('DESCRIPTION:'):
                self.script.description = line[len('DESCRIPTION:'):].strip()
            
            elif line.startswith('WELCOME:'):
                self.script.welcome_message = line[len('WELCOME:'):].strip()
                self.current_section = 'welcome'
            
            elif line.startswith('FINAL:'):
                self.script.final_message = line[len('FINAL:'):].strip()
                self.current_section = 'final'
            
            elif line.startswith('QUIT:'):
                quit_words = line[len('QUIT:'):].strip().split()
                self.script.quit_words.extend(quit_words)
                self.current_section = 'quit'
            
            elif line.startswith('PRE:'):
                self.current_section = 'pre'
                i += 1
                # Read pre-substitution rules
                while i < len(lines):
                    line = lines[i].strip()
                    if not line or line.startswith('#'):
                        i += 1
                        continue
                    if ':' in line and not line.startswith(('KEYWORD', 'DECOMP', 'REASSEMBLY', 'POST', 'WELCOME', 'FINAL', 'QUIT', 'SYNONYM', 'DEFAULT', 'SENTIMENT', 'NAME', 'DESCRIPTION')):
                        pattern, replacement = line.split('->')
                        self.script.pre_substitutions[pattern.strip()] = replacement.strip()
                        i += 1
                    else:
                        break
                continue
            
            elif line.startswith('KEYWORD:'):
                parts = line[len('KEYWORD:'):].strip().split()
                if len(parts) >= 2:
                    word = parts[0]
                    priority = int(parts[1])
                    self.current_keyword = Keyword(word, priority, [])
                    
                    # Check for additional flags
                    if 'SYNONYM' in line:
                        syn_start = line.find('SYNONYM')
                        if syn_start > 0:
                            syn_str = line[syn_start:].replace('SYNONYM', '').strip()
                            if syn_str:
                                self.current_keyword.synonyms = syn_str.split(',')
                    
                    self.script.keywords.append(self.current_keyword)
                self.current_section = 'keyword'
            
            elif line.startswith('DECOMP:'):
                pattern = line[len('DECOMP:'):].strip()
                
                # Check for context requirement
                context_required = 'CONTEXT' in line.upper()
                
                self.current_decomp = DecompositionRule(pattern, [])
                self.current_decomp.context_required = context_required
                
                # Look for reassembly rules
                i += 1
                while i < len(lines):
                    line = lines[i].strip()
                    if not line or line.startswith('#'):
                        i += 1
                        continue
                    if line.startswith('REASSEMBLY:'):
                        template = line[len('REASSEMBLY:'):].strip()
                        
                        # Check for sentiment and memory flags
                        sentiment = Sentiment.NEUTRAL
                        memory_trigger = False
                        
                        if 'SENTIMENT:POSITIVE' in line.upper():
                            sentiment = Sentiment.POSITIVE
                        elif 'SENTIMENT:NEGATIVE' in line.upper():
                            sentiment = Sentiment.NEGATIVE
                        elif 'SENTIMENT:MIXED' in line.upper():
                            sentiment = Sentiment.MIXED
                        
                        if 'MEMORY' in line.upper():
                            memory_trigger = True
                        
                        reassembly = ReassemblyRule(template, sentiment, memory_trigger)
                        self.current_decomp.reassembly_rules.append(reassembly)
                        i += 1
                    else:
                        break
                
                if self.current_keyword:
                    self.current_keyword.decomposition_rules.append(self.current_decomp)
                continue
            
            elif line.startswith('POST:'):
                self.current_section = 'post'
                i += 1
                # Read post-substitution rules
                while i < len(lines):
                    line = lines[i].strip()
                    if not line or line.startswith('#'):
                        i += 1
                        continue
                    if ':' in line and not line.startswith(('KEYWORD', 'DECOMP', 'REASSEMBLY', 'PRE', 'WELCOME', 'FINAL', 'QUIT', 'SYNONYM', 'DEFAULT', 'SENTIMENT')):
                        pattern, replacement = line.split('->')
                        self.script.post_substitutions[pattern.strip()] = replacement.strip()
                        i += 1
                    else:
                        break
                continue
            
            elif line.startswith('SYNONYM:'):
                parts = line[len('SYNONYM:'):].strip().split()
                if len(parts) >= 2:
                    word = parts[0]
                    synonyms = parts[1:]
                    self.script.synonyms[word] = synonyms
            
            elif line.startswith('DEFAULT:'):
                response = line[len('DEFAULT:'):].strip()
                self.script.default_responses.append(response)
            
            elif line.startswith('SENTIMENT:'):
                # Parse sentiment-specific responses
                # Format: SENTIMENT:POSITIVE: response
                parts = line[len('SENTIMENT:'):].strip().split(':', 1)
                if len(parts) >= 2:
                    sentiment_type = parts[0].strip().lower()
                    response = parts[1].strip()
                    if sentiment_type not in self.script.sentiment_responses:
                        self.script.sentiment_responses[sentiment_type] = {}
                    # Store with generic key for now
                    self.script.sentiment_responses[sentiment_type]['default'] = response
            
            i += 1
        
        return self.script


if __name__ == "__main__":
    # Test the parser
    parser = ScriptParser()
    print("Enhanced script parser module loaded successfully")
